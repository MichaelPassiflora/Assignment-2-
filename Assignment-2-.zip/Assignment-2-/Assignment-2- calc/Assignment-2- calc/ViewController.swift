//
//  ViewController.swift
//  Assignment-2- calc
//
//  Created by Michael Bravo on 9/6/20.
//  Copyright © 2020 Michael Bravo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ValueA: UITextField!
    @IBOutlet weak var ValueB: UITextField!
    @IBOutlet weak var Result: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Sum(_ sender: Any) {
        var a = ValueA.text
        var b = ValueB.text
        
        var Answer = a! + b!
        Result.text = (Answer)

    }
}

